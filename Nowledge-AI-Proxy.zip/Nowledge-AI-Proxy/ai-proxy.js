/**
 * Nowledge AI 代理 · 便携分享版（零第三方依赖）
 *
 * 用途：
 *   1) 转发 AI 请求，绕过浏览器跨域(CORS)限制；支持 SSE 流式与自定义请求头(api-key / Bearer)。
 *   2) 首页显示引导页，给出可直接复制的代理地址。本包不含任何 Nowledge HTML 文件。
 *      可选：若同目录存在 app.html，则改为托管它并自动预置代理地址（无需手填）。
 *   3) 仅监听 127.0.0.1，不对外网开放。
 *
 * 启动： node ai-proxy.js      （或双击 启动.bat）
 * 环境变量： PORT=8080  默认端口，被占用时自动 +1 顺延
 *           NO_OPEN=1   启动后不自动打开浏览器
 */
const http = require('http');
const https = require('https');
const fs = require('fs');
const path = require('path');
const { URL } = require('url');
const { exec } = require('child_process');

const BASE_PORT = Number(process.env.PORT || 8080);
const MAX_TRY = 20;
const HOP = ['connection', 'transfer-encoding'];
const APP_FILE = path.join(__dirname, 'app.html');
const PORT_FILE = path.join(__dirname, 'proxy.port');

function allowCors(res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET,POST,PUT,DELETE,OPTIONS,PATCH');
  res.setHeader('Access-Control-Allow-Headers', '*');
  res.setHeader('Access-Control-Expose-Headers', '*');
  // Chrome 私有网络访问(PNA)：允许从本地/公网页面访问 127.0.0.1
  res.setHeader('Access-Control-Allow-Private-Network', 'true');
}
function badRequest(res, msg) {
  allowCors(res);
  res.statusCode = 400;
  res.setHeader('Content-Type', 'text/plain; charset=utf-8');
  res.end(msg);
}
function readBody(req) {
  return new Promise((resolve) => {
    const chunks = [];
    req.on('data', (c) => chunks.push(c));
    req.on('end', () => resolve(Buffer.concat(chunks)));
  });
}

/** 无 app.html 时的引导页：只负责把代理地址交到用户手上（内容内嵌，不落盘成 html 文件）。 */
function guidePage(proxyUrl, port) {
  return `<!doctype html>
<html lang="zh-CN"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>今课 Nowledge · AI 代理</title>
<style>
*{box-sizing:border-box}
body{margin:0;background:#f5f7fb;color:#1c2430;font:15px/1.7 -apple-system,"Segoe UI","Microsoft YaHei",sans-serif;padding:36px 18px}
.box{max-width:660px;margin:0 auto;background:#fff;border:1px solid #e3e8f0;border-radius:14px;padding:30px 32px;box-shadow:0 6px 28px rgba(20,40,80,.07)}
h1{margin:0 0 6px;font-size:23px;letter-spacing:.5px}
.sub{color:#6b7787;margin:0 0 24px;font-size:14px}
label{display:block;font-weight:600;margin-bottom:8px;font-size:13px;color:#46536a}
.row{display:flex;gap:8px}
input{flex:1;min-width:0;padding:11px 13px;border:1px solid #cfd8e6;border-radius:8px;font:13px/1.4 Consolas,Monaco,monospace;background:#f8faff;color:#1c2430}
button{padding:0 20px;border:0;border-radius:8px;background:#3454d1;color:#fff;font-size:14px;cursor:pointer}
button:hover{background:#2743b4}
ol{margin:24px 0 0;padding-left:22px;color:#3b4658}
li{margin:7px 0}
.tip{margin:22px 0 0;padding:13px 15px;background:#f0f5ff;border-left:3px solid #3454d1;border-radius:0 8px 8px 0;font-size:13px;color:#46536a}
code{background:#e8eefb;padding:2px 6px;border-radius:4px;font-size:12px}
.foot{margin:26px 0 0;padding-top:16px;border-top:1px solid #eceff5;color:#8a95a6;font-size:12px}
.ok{color:#1b8a5a;font-weight:600}
</style></head><body>
<div class="box">
<h1>AI 代理已启动</h1>
<p class="sub">这个包只包含代理，不含 Nowledge 网页。你的 HTML 照常独立使用，只要在 AI 设置里填一次下面的地址。</p>
<label>CORS 代理地址</label>
<div class="row"><input id="u" readonly value="${proxyUrl}"><button id="b">复制</button></div>
<ol>
<li>打开你自己的 Nowledge HTML 页面</li>
<li>进入 设置 → AI 设置 → 添加 AI，填写名称 / Base URL / 模型 / API Key</li>
<li>把上面这串地址粘到「CORS 代理」一栏，保存（会自动测试连接）</li>
</ol>
<p class="tip">可选：把 Nowledge 的 HTML 复制到本文件夹并改名为 <code>app.html</code>，之后刷新本页会直接打开它，并自动把代理地址填好，连复制都不用。</p>
<p class="foot"><span class="ok">● RUNNING</span> &nbsp; 端口 ${port} &nbsp;·&nbsp; 仅监听 127.0.0.1，局域网访问不到 &nbsp;·&nbsp; 用完请双击 <code>stop.bat</code></p>
</div>
<script>
var b=document.getElementById('b'), u=document.getElementById('u');
b.onclick=function(){ u.select(); try{ navigator.clipboard.writeText(u.value); }catch(e){ document.execCommand('copy'); } b.textContent='已复制'; setTimeout(function(){b.textContent='复制';},1600); };
</script></body></html>`;
}

/**
 * 注入到（可选的）app.html 的 <head>：自动把「CORS 代理」预置为当前页面的同源地址。
 * 用 location.origin 拼接的好处：端口自动顺延也能跟上、请求落在同源无跨域问题，
 * 且这是一份绝对地址，配置被导出到别的页面时依然指向本代理。
 */
function injectScript() {
  return `<script>(function(){
  var p = location.origin + '/?url={url}';
  function ensure(obj){
    try {
      if (obj && obj.ai && Array.isArray(obj.ai.list)) {
        obj.ai.list.forEach(function(c){ c.proxy = p; });
      }
    } catch (e) {}
    return obj;
  }
  // 1) 修正已有数据（本脚本位于主程序之前执行，早于 Store.read）
  try {
    var raw = localStorage.getItem('todayclass.v1');
    if (raw) localStorage.setItem('todayclass.v1', JSON.stringify(ensure(JSON.parse(raw))));
  } catch (e) {}
  // 2) 拦截后续写入：无论表单是否被清空，新建/编辑的 AI 一律带上代理
  try {
    var orig = Storage.prototype.setItem;
    Storage.prototype.setItem = function(k, v){
      if (k === 'todayclass.v1') {
        try { v = JSON.stringify(ensure(JSON.parse(v))); } catch (e) {}
      }
      return orig.call(this, k, v);
    };
  } catch (e) {}
  // 3) 仅用于界面显示：把「CORS 代理」输入框也填上
  function fill(){
    try {
      var el = document.getElementById('aiProxy');
      if (el && !el.value) el.value = p;
    } catch (e) {}
  }
  try { new MutationObserver(fill).observe(document.documentElement, {childList:true, subtree:true}); } catch (e) {}
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', fill);
  else fill();
  setInterval(fill, 500);
})();</script>`;
}

function serveApp(res) {
  const port = server.address() ? server.address().port : BASE_PORT;
  const proxyUrl = 'http://127.0.0.1:' + port + '/?url={url}';
  let html;
  if (fs.existsSync(APP_FILE)) {
    // 可选增强：同目录放了 app.html 时直接托管并自动填好代理配置
    html = fs.readFileSync(APP_FILE, 'utf8');
    if (html.indexOf('</head>') !== -1) html = html.replace('</head>', injectScript() + '\n</head>');
    else html = injectScript() + '\n' + html;
  } else {
    html = guidePage(proxyUrl, port);
  }
  allowCors(res);
  res.statusCode = 200;
  res.setHeader('Content-Type', 'text/html; charset=utf-8');
  res.setHeader('Cache-Control', 'no-store');
  res.end(html);
}

const server = http.createServer(async (req, res) => {
  // 1) 预检
  if (req.method === 'OPTIONS') {
    allowCors(res);
    res.statusCode = 204;
    res.end();
    return;
  }

  const parsed = new URL(req.url, 'http://127.0.0.1');

  // 2) 健康检查（供启动器判断就绪）
  if (parsed.pathname === '/health') {
    allowCors(res);
    res.setHeader('Content-Type', 'application/json; charset=utf-8');
    res.end(JSON.stringify({ ok: true, port: server.address().port }));
    return;
  }

  // 3) 首页 → 托管 app.html（仅当没有 ?url= 参数时）
  const wantApp = (parsed.pathname === '/' || parsed.pathname === '/index.html' ||
                   parsed.pathname === '/app' || parsed.pathname === '/app.html');
  if (wantApp && !parsed.searchParams.has('url')) {
    return serveApp(res);
  }

  // 4) 解析要转发的目标地址：优先 ?url=，否则把路径当作目标
  let target = parsed.searchParams.get('url');
  if (!target) {
    try { target = decodeURIComponent(parsed.pathname.replace(/^\//, '')); }
    catch (e) { target = parsed.pathname.replace(/^\//, ''); }
  }
  if (!target || !/^https?:\/\//i.test(target)) {
    return badRequest(res, '缺少有效的目标地址（?url=）。');
  }

  let targetUrl;
  try { targetUrl = new URL(target); }
  catch (e) { return badRequest(res, '目标地址解析失败：' + e.message); }

  const body = (req.method === 'GET' || req.method === 'HEAD') ? undefined : await readBody(req);

  // 5) 透传请求头（去掉逐跳头与 host）
  const outHeaders = {};
  for (const [k, v] of Object.entries(req.headers)) {
    const lk = k.toLowerCase();
    if (lk === 'host' || HOP.includes(lk)) continue;
    outHeaders[k] = v;
  }

  const transport = targetUrl.protocol === 'https:' ? https : http;
  const options = {
    method: req.method,
    headers: outHeaders,
    hostname: targetUrl.hostname,
    port: targetUrl.port || (targetUrl.protocol === 'https:' ? 443 : 80),
    path: targetUrl.pathname + targetUrl.search
  };

  try {
    const proxyReq = transport.request(options, (proxyRes) => {
      allowCors(res);
      res.statusCode = proxyRes.statusCode;
      for (const [k, v] of Object.entries(proxyRes.headers)) {
        const lk = k.toLowerCase();
        // 让 Node 重新处理分帧，避免与上游 chunked/content-length 冲突
        if (HOP.includes(lk) || lk === 'content-length') continue;
        try { res.setHeader(k, v); } catch (e) {}
      }
      proxyRes.pipe(res);
    });
    proxyReq.on('error', (e) => {
      allowCors(res);
      if (!res.headersSent) res.statusCode = 502;
      res.end('代理转发失败：' + e.message);
    });
    if (body && body.length) proxyReq.write(body);
    proxyReq.end();
  } catch (e) {
    allowCors(res);
    res.statusCode = 500;
    res.end('代理错误：' + e.message);
  }
});

// 端口顺延：被占用时自动 +1，最多尝试 MAX_TRY 次
let port = BASE_PORT;
let tries = 0;
server.on('error', (e) => {
  if (e.code === 'EADDRINUSE' && tries++ < MAX_TRY) {
    port += 1;
    setTimeout(() => server.listen(port, '127.0.0.1'), 60);
  } else {
    console.error('无法启动：' + e.message);
    process.exit(1);
  }
});

server.listen(port, '127.0.0.1', () => {
  const actual = server.address().port;
  const url = 'http://127.0.0.1:' + actual + '/';
  try { fs.writeFileSync(PORT_FILE, String(actual)); } catch (e) {}
  console.log('');
  console.log('  Nowledge AI 代理已启动');
  console.log('  引导页面 : ' + url);
  console.log('  代理地址 : ' + url + '?url={url}   <-- 填到 AI 设置的「CORS 代理」');
  if (fs.existsSync(APP_FILE)) console.log('  检测到 app.html：已启用自动配置');
  console.log('  仅监听 127.0.0.1，关闭窗口或选菜单 [2] 即可停止');
  console.log('');
  if (!process.env.NO_OPEN) {
    const cmd = process.platform === 'win32' ? 'start "" "' + url + '"'
              : process.platform === 'darwin' ? 'open "' + url + '"'
              : 'xdg-open "' + url + '"';
    exec(cmd, () => {});
  }
});

process.on('SIGINT', () => { server.close(() => process.exit(0)); });
process.on('SIGTERM', () => { server.close(() => process.exit(0)); });
