#!/usr/bin/env bash
# Nowledge AI Proxy - macOS / Linux launcher
# Double-click is not always supported on Linux; run:  bash start-mac-linux.sh
cd "$(dirname "$0")" || exit 1

echo "============================================"
echo "  Nowledge AI Proxy  (macOS / Linux)"
echo "============================================"

# Prefer a Node next to this script (if you ever add a portable build), then system node.
NODE_BIN=""
if [ -x "./node" ]; then
  NODE_BIN="./node"
elif command -v node >/dev/null 2>&1; then
  NODE_BIN="node"
else
  echo "[ERROR] Node.js not found on this machine."
  echo "This package ships a portable Node for Windows (node.exe)."
  echo "On macOS / Linux please install Node.js once: https://nodejs.org"
  echo "Then run this script again."
  read -r -p "Press Enter to close..." _
  exit 1
fi

if [ -f proxy.pid ] && kill -0 "$(cat proxy.pid)" 2>/dev/null; then
  echo "Proxy already running (PID $(cat proxy.pid))."
else
  rm -f proxy.port
  nohup env NO_OPEN=1 "$NODE_BIN" ai-proxy.js > proxy.log 2> proxy.err &
  echo $! > proxy.pid
  echo "Starting proxy (PID $(cat proxy.pid))..."
fi

# Wait for the port file written by the proxy (handles auto port shift)
PORT=""
for _ in $(seq 1 20); do
  [ -f proxy.port ] && PORT="$(cat proxy.port)"
  [ -n "$PORT" ] && break
  sleep 0.5
done

if [ -z "$PORT" ]; then
  echo "[WARN] Proxy is slow to start. Check proxy.err / proxy.log"
  exit 1
fi

URL="http://127.0.0.1:$PORT/"
echo "Proxy ready at $URL"
if command -v open >/dev/null 2>&1; then open "$URL"
elif command -v xdg-open >/dev/null 2>&1; then xdg-open "$URL"
else echo "Open this URL in your browser: $URL"; fi

echo ""
echo "To stop:  kill \$(cat proxy.pid)"
echo "Log:      tail -f proxy.log"
echo "Press Ctrl+C to close this window (proxy keeps running)."
read -r -p "Press Enter to close..." _
