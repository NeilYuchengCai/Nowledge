@echo off
setlocal
cd /d "%~dp0"
title Nowledge AI Proxy
rem The launcher opens the browser; NO_OPEN keeps the proxy from opening a second tab.
set "NO_OPEN=1"

echo ============================================
echo   Nowledge AI Proxy  -  portable, no install
echo ============================================
if not exist "node.exe" goto errnode
if not exist "ai-proxy.js" goto errfile
goto check_first

:errnode
echo [ERROR] node.exe not found in this folder.
echo Keep all files together. Do not move start.bat alone.
pause
exit /b 1

:errfile
echo [ERROR] ai-proxy.js not found in this folder.
pause
exit /b 1

:check_first
call :check
if "%RUNNING%"=="1" goto already

:startnew
echo Starting proxy...
if exist proxy.port del /f /q proxy.port >nul 2>&1
powershell -NoProfile -Command "$d=(Get-Location).Path; $p=Start-Process -FilePath (Join-Path $d 'node.exe') -ArgumentList 'ai-proxy.js' -WorkingDirectory $d -WindowStyle Hidden -PassThru -RedirectStandardOutput (Join-Path $d 'proxy.log') -RedirectStandardError (Join-Path $d 'proxy.err'); [IO.File]::WriteAllText((Join-Path $d 'proxy.pid'),[string]$p.Id)"
if errorlevel 1 goto errstart

set TRIES=0
set PORT=
:wait
if exist proxy.port set /p PORT=<proxy.port
if defined PORT goto ready
set /a TRIES+=1
if %TRIES% GEQ 20 goto slow
ping -n 2 127.0.0.1 >nul 2>&1
goto wait

:errstart
echo [ERROR] Failed to start. See proxy.err
pause
exit /b 1

:slow
echo [WARN] Proxy is slow to start. Check proxy.err / proxy.log
goto menu

:ready
echo Proxy ready at http://127.0.0.1:%PORT%/
start "" "http://127.0.0.1:%PORT%/"
echo Browser opened. Keep this window, or use the menu to stop.
goto menu

:already
echo Proxy already running (PID %PID%).
set PORT=
if exist proxy.port set /p PORT=<proxy.port
if not defined PORT set PORT=8080
start "" "http://127.0.0.1:%PORT%/"
echo Browser opened at http://127.0.0.1:%PORT%/
goto menu

:menu
echo.
echo --------------------------------------------
call :check
if "%RUNNING%"=="1" goto status_up
echo   Status : STOPPED
goto status_done
:status_up
echo   Status : RUNNING   PID %PID%
:status_done
set PORT=
if exist proxy.port set /p PORT=<proxy.port
if not defined PORT set PORT=?
echo   URL    : http://127.0.0.1:%PORT%/
echo --------------------------------------------
echo   [1] Restart proxy
echo   [2] Stop proxy
echo   [3] Show recent log
echo   [0] Exit  (proxy keeps running in background)
echo --------------------------------------------
set /p CHOICE=Select [0-3]:
if "%CHOICE%"=="1" goto restart
if "%CHOICE%"=="2" goto stop
if "%CHOICE%"=="3" goto log
if "%CHOICE%"=="0" goto end
echo Invalid choice.
goto menu

:restart
call :check
if "%RUNNING%"=="1" taskkill /PID %PID% /F /T >nul 2>&1
del /f /q proxy.pid proxy.port >nul 2>&1
set PID=
set RUNNING=0
goto startnew

:stop
call :check
if "%RUNNING%"=="0" goto stop_none
taskkill /PID %PID% /F /T >nul 2>&1
echo Proxy stopped.
goto stop_done
:stop_none
echo Proxy was not running.
:stop_done
del /f /q proxy.pid proxy.port >nul 2>&1
set PID=
set RUNNING=0
goto menu

:log
echo --- proxy.log (tail) ---
if exist proxy.log powershell -NoProfile -Command "Get-Content (Join-Path (Get-Location).Path 'proxy.log') -Tail 15"
echo --- proxy.err (tail) ---
if exist proxy.err powershell -NoProfile -Command "Get-Content (Join-Path (Get-Location).Path 'proxy.err') -Tail 8"
goto menu

:end
echo Bye. Proxy is still running in background; use [2] or stop.bat to kill it.
exit /b 0

:check
set RUNNING=0
set PID=
if not exist proxy.pid goto :eof
set /p PID=<proxy.pid
if not defined PID goto :eof
tasklist /fi "PID eq %PID%" 2>nul | findstr /r "%PID%" >nul && set RUNNING=1
goto :eof
