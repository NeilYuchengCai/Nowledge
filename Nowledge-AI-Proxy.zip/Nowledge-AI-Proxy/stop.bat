@echo off
setlocal
cd /d "%~dp0"
if not exist proxy.pid goto none
set /p PID=<proxy.pid
if not defined PID goto none
taskkill /PID %PID% /F /T >nul 2>&1
if errorlevel 1 goto failed
echo Proxy stopped (PID %PID%).
goto cleanup
:failed
echo Could not kill PID %PID% (already gone?).
goto cleanup
:none
echo Proxy was not running.
:cleanup
del /f /q proxy.pid proxy.port >nul 2>&1
echo Done.
timeout /t 2 >nul
exit /b 0
